import junit.framework.Assert;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class empJunit {
	static EmpCollection collectionhelper = null;

	@Test
	public void testAddNewEmp() {
		EmpSchema es = new EmpSchema(123, "Parth", "ABCDE12345", 1245.00);
		Assert.assertNotNull(es.toString());

	}

	@Test
	public void getIncomeTaxAmt() {
		String a = new String();
		EmpService esc = new EmpService();
		Assert.assertNotNull(esc.toString());

	}

	@AfterClass
	public static void afterClass() {
		collectionhelper = new EmpCollection();
		collectionhelper = null;

	}

	@BeforeClass
	public static void beforeClass() {
		collectionhelper = new EmpCollection();
		EmpSchema es = new EmpSchema(123, "Parth", "ABCDE12345", 12345.00);

	}

}
